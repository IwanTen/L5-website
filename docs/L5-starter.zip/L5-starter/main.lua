require("L5")

function setup()
  size(400, 400)
end

function draw()
   background(220)
end
